<?php

$conn = mysqli_connect('localhost','root','','gym_db');

?>